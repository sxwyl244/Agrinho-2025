let perguntas = [
  {
    texto: "1. Com que frequência você usa transporte individual?",
    opcoes: ["Nunca", "Às vezes", "Todos os dias"]
  },
  {
    texto: "2. Com que frequência você consome carne vermelha?",
    opcoes: ["Raramente", "2 a 3 vezes por semana", "Todos os dias"]
  },
  {
    texto: "3. Você costuma economizar energia elétrica?",
    opcoes: ["Sempre", "Às vezes", "Não"]
  },
  {
    texto: "4. Você separa o lixo reciclável?",
    opcoes: ["Sempre", "Às vezes", "Nunca"]
  },
  {
    texto: "5. Você reutiliza água?",
    opcoes: ["Sim", "Às vezes", "Não"]
  }
];

let perguntaAtual = 0;
let pontuacao = 0;
let resultadoFinal = "";

function setup() {
  createCanvas(600, 400);
  textAlign(LEFT, TOP);
  textSize(18);
}

function draw() {
  background(220);
  
  if (perguntaAtual < perguntas.length) {
    fill(0);
    text(perguntas[perguntaAtual].texto, 20, 40);
    
    for (let i = 0; i < 3; i++) {
      drawBotao(perguntas[perguntaAtual].opcoes[i], 20, 100 + i * 60, i + 1);
    }
  } else {
    fill(0);
    textSize(20);
    text("Resultado da sua Pegada Ecológica:", 20, 50);
    textSize(18);
    text(resultadoFinal, 20, 100);
  }
}

function drawBotao(texto, x, y, valor) {
  fill(180);
  rect(x, y, 400, 40, 8);
  fill(0);
  text(texto, x + 10, y + 10);
}

function mousePressed() {
  if (perguntaAtual >= perguntas.length) return;

  for (let i = 0; i < 3; i++) {
    let x = 20;
    let y = 100 + i * 60;
    if (mouseX > x && mouseX < x + 400 && mouseY > y && mouseY < y + 40) {
      pontuacao += i + 1;
      perguntaAtual++;

      if (perguntaAtual === perguntas.length) {
        calcularResultado();
      }
    }
  }
}

function calcularResultado() {
  if (pontuacao <= 7) {
    resultadoFinal = "Pegada BAIXA 🌱\nParabéns! Continue com hábitos sustentáveis.";
  } else if (pontuacao <= 11) {
    resultadoFinal = "Pegada MÉDIA 🌿\nVocê está no caminho certo, mas pode melhorar.";
  } else {
    resultadoFinal = "Pegada ALTA 🌍\nAtenção! Reveja seus hábitos e cuide do planeta.";
  }
}
